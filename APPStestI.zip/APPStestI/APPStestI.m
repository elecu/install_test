(* ::Package:: *)

BeginPackage["APPStestI`"]

   Print [Style[" Mathematica application ","Text"]];

EndPackage[]
