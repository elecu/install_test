(* ::Package:: *)

BeginPackage["APPStestI`SUBappsA`"]

  Needs[ "APPStestI`SUBappsC`"]
  Unprotect["SUBappsA`*"];    
  ClearAll["SUBappsA`*"]; 

  funI::usage = "funI[ x]"

Begin["`Private`"] (* Begin Private Context *)

  funI[xp_] := Module[ {yp}, yp = xp^2+x; yp + 1 ]

End[] (* End Private Context *)

  Protect["SUBappsA`*"];

EndPackage[]
