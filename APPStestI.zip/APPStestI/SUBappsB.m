(* ::Package:: *)

BeginPackage["APPStestI`SUBappsB`"]

  Needs[ "APPStestI`SUBappsA`"]
  Needs[ "APPStestI`SUBappsC`"]
  Unprotect["SUBappsB`*"];
  ClearAll["SUBappsB`*"];

  funII::usage = "funII[w] computes a simple function."

Begin["`Private`"] 

  funII[ wp_] := Module[ {zp}, zp = wp^3+ funI[WW]; zp + 1]

End[]

  Protect["SUBappsB`*"];

EndPackage[]
