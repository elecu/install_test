(* ::Package:: *)

BeginPackage["APPStestI`SUBappsC`"]

  Unprotect["SUBappsC`*"];
  ClearAll["SUBappsC`*"];

  y::usage= "5" 
  WW::usage= "10" 
  x::usage= "3" 
  z::usage= "4" 

Begin["`Private`"] 

  {  y = 5,  WW = 10,  x = 3,  z = 4 };

End[] 

  Protect["SUBappsC`*"];

EndPackage[]
